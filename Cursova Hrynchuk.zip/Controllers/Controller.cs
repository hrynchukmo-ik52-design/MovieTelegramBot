using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private static readonly HttpClient _httpClient = new HttpClient();
    List<string> models = new List<string>() { "gemini-3.1-pro-preview", "gemini-3-flash-preview", "gemini-3.1-flash-lite-preview" };
    
    private static readonly Dictionary<long, List<object>> _chatHistories = new();
    private static readonly List<FavoriteItem> _favorites = new();

    [HttpPost]
    public async Task<IActionResult> PostMessage([FromBody] UserRequest request)
    {
        if (!_chatHistories.ContainsKey(request.ChatId)) 
            _chatHistories[request.ChatId] = new List<object>();
        
        var history = _chatHistories[request.ChatId];
        history.Add(new { role = "user", parts = new[] { new { text = request.UserMessage } } });

        if (history.Count > 10) history.RemoveRange(0, 2);

        string response;
        foreach (var m in models)
        {
            try
            {
                Console.WriteLine(m);
                GeminiApiUrl = $"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={_settings.Gemini}";
                
                response = await GetGeminiResponseAsync(request.ChatId, history);

                history.Add(new { role = "model", parts = new[] { new { text = response } } });

                return Ok(new { reply = response });
            }
            catch { }
        }
        return StatusCode(StatusCodes.Status500InternalServerError);
    }

    private readonly ApiSettings _settings;
    private string GeminiApiUrl;
    public UsersController(IOptions<ApiSettings> options)
    {
        _settings = options.Value;
        GeminiApiUrl = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite-preview:generateContent?key={_settings.Gemini}";
    }

    async Task<string> GetGeminiResponseAsync(long chatId, List<object> history)
    {
        string systemInstructionText =
     "Ти — професійний кіноконсультант. Твоя єдина мета — рекомендувати фільми. Спілкуйся максимально ввічливо, лаконічно. Формат: Назва фільму та стислий трейлер (2-3 речення). Якщо в тебе не питають про кіно а про другу іншу тему відповідай що ти на цьому не спеціалізуєшся. Будь уважним: коли люди тебе питають про серіали - не давай серіал, бо ти спеціалізуєшся на фільмах. також давай строго один фільм із джанру який тебе попросять не давай багато ";

        var requestBody = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = systemInstructionText } }
            },
            contents = history 
        };

        var jsonContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync(GeminiApiUrl, jsonContent);

        if (!response.IsSuccessStatusCode)
        {
            response.EnsureSuccessStatusCode(); 
        }

        var responseString = await response.Content.ReadAsStringAsync();
        var jsonNode = JsonNode.Parse(responseString);
        var textNode = jsonNode?["candidates"]?[0]?["content"]?["parts"]?[0]?["text"];
        
        string finalResult = textNode?.ToString() ?? "Не вдалося згенерувати рекомендацію.";
        return finalResult;
    }

    [HttpPost("add-favorite")]
    public IActionResult AddFavorite([FromBody] FavoriteItem item)
    {
        if (string.IsNullOrEmpty(item.MovieTitle)) return BadRequest();
        if (!_favorites.Any(f => f.ChatId == item.ChatId && f.MovieTitle == item.MovieTitle))
            _favorites.Add(item);
        return Ok(new { status = "success" });
    }

    
    [HttpGet("favorites/{chatId}")]
    public IActionResult GetFavorites(long chatId)
    {
        var list = _favorites.Where(f => f.ChatId == chatId).ToList();
        return Ok(new { favorites = list });
    }

    
    [HttpDelete("favorites/{chatId}/{movieTitle}")]
    public IActionResult DeleteFavorite(long chatId, string movieTitle)
    {
        _favorites.RemoveAll(f => f.ChatId == chatId && f.MovieTitle == movieTitle);
        return Ok(new { status = "success" });
    }


    [HttpPut("favorites/update")]
    public IActionResult UpdateFavorite([FromBody] FavoriteItem updateRequest)
    {
        var item = _favorites.FirstOrDefault(f => f.ChatId == updateRequest.ChatId && f.MovieTitle == updateRequest.MovieTitle);
        if (item != null)
        {
            item.Note = updateRequest.Note;
            return Ok(new { status = "success" });
        }
        return NotFound();
    }

    [HttpGet("active-users")]
public IActionResult GetActiveUsers()
{
   
    var userIds = _chatHistories.Keys.ToList();
    
    return Ok(new { 
        count = userIds.Count, 
        userIds = userIds 
    });
}

    public class UserRequest
    {
        public long ChatId { get; set; }
        public string UserMessage { get; set; }
    }

    public class FavoriteItem 
    { 
        public long ChatId { get; set; } 
        public string MovieTitle { get; set; } 

        public string? Note { get; set; } 
    }
}